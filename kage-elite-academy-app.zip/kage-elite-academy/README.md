# KAGE Focus v3

A KAGE-first focus and app-blocking experience with Nori available as the AI companion.

## Session timing
- Length mode supports preset and custom durations.
- End Time mode uses a real calendar day + exact clock time.
- The picker exposes 12-hour time, 5-minute increments, AM/PM, and an exact native time field.
- A session cannot start when its end time is already in the past.
- Active sessions show a live countdown and progress indicator.
- The session automatically ends at the stored `endAt` timestamp and releases the configured blocklist in the prototype.
- Focus minutes are recorded from actual elapsed time, not from a prefilled value.

## Native Android note
The web prototype models the complete session state and timing. Actual Android app enforcement requires native Android integration (for example, Usage Access / device-management capabilities as appropriate to the target implementation).

## Nori
Nori is available from the intro, home focus screen, Study, and the floating assistant. The primary AI provider remains Gemini in this prototype.

## Advanced Session Engine v5

The focus session layer is timestamp-first: `startAt` and `endAt` are persisted as ISO timestamps and are the source of truth. The countdown is only presentation. The engine rehydrates on page visibility/page-show events, automatically completes sessions whose exact end timestamp has passed, and restores the selected blocklist while an active session is valid. Strict Focus adds an intentional exit confirmation. Scheduled sessions continue to use persisted start/end timestamps and can be promoted when their start time arrives while the app is running.

The browser artifact simulates app blocking. Real Android system-level app restriction requires a native enforcement service and Android permissions/managed-device APIs appropriate to the deployment model; the UI does not claim browser storage can make a device unbreakable.

## KAGE Focus v7 onboarding

The onboarding is now a code-built, mobile-first four-screen carousel inspired by the approved KAGE Focus visual direction rather than a flat poster image. The previous `assets/kage-focus-intro.png` poster has been removed.

Screens:
1. **Less Distraction. More You.** — core value proposition, phone home preview, feature stack, Nori callout.
2. **Smart Sessions** — Now/Later/Recurring, duration, blocklist and session setup preview.
3. **Total Control** — exact end time, timestamp-based session behavior and automatic completion preview.
4. **Meet Nori** — AI focus companion introduction and capabilities.

Interaction:
- Four clickable navigation dots.
- Next / Get Started buttons.
- Swipe left/right on touch devices.
- Keyboard arrow navigation on desktop.
- Skip exits onboarding.
- Get Started exits onboarding into the existing KAGE Focus app.

The artwork is built from HTML/CSS components, gradients, device mockups and existing Nori/KAGE assets so it scales cleanly to phone screens instead of displaying a cropped composite image.


## v8 focus-plan update
- The Nori onboarding artwork uses a cleaned crop that removes the `VER. 1.0` badge and its small decorative line without cutting into Nori's face, hair, or necessary body details.
- Sessions now support **long-term focus plans** with a plan horizon measured in days, weeks, months, or years.
- Each plan supports daily, weekly, monthly, or yearly repetition, a selected start time, a per-occurrence focus length, selected weekdays for weekly plans, and a specific blocklist.
- Future occurrences are materialized into timestamped scheduled sessions and rebuilt after app reopen/visibility changes, preventing the plan from depending on a visual countdown.
- Deleting a plan removes the plan and its future generated occurrences while preserving completed session history.
- The browser artifact persists rules and timestamps locally. Actual Android app blocking while the app is fully closed still requires the native enforcement/scheduling layer described in `native-reference/`.
