package com.yourapp.jarvis

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sqrt

enum class JarvisState {
    IDLE, LISTENING, THINKING, SPEAKING,
    PROUD, DISAPPOINTED, ENCOURAGING, SUCCESS, SURPRISED,
    CONCERNED, STRICT
}

enum class JarvisSkin { AURORA, HUD, IRIS }
enum class JarvisPose { DEFAULT, ANALYSIS, EXECUTE, BOOK, WARNING, SUCCESS, RECOVERY, FOCUS }

class JarvisController {
    var state by mutableStateOf(JarvisState.IDLE); private set
    var level by mutableStateOf(0f); private set
    var pose by mutableStateOf(JarvisPose.DEFAULT); private set

    fun setState(next: JarvisState) { state = next }
    fun setLevel(v: Float) { level = v.coerceIn(0f, 1f) }
    fun setPose(next: JarvisPose) { pose = next }
}

fun colorFor(state: JarvisState): Color = when (state) {
    JarvisState.IDLE -> Color(0xFF5AB4FF)
    JarvisState.LISTENING -> Color(0xFF46E6FF)
    JarvisState.THINKING -> Color(0xFFC882FF)
    JarvisState.SPEAKING -> Color(0xFF5AFFBE)
    JarvisState.PROUD -> Color(0xFFE8C56B)
    JarvisState.DISAPPOINTED -> Color(0xFF8A97A6)
    JarvisState.ENCOURAGING -> Color(0xFFFFB86B)
    JarvisState.SUCCESS -> Color(0xFF6BFFA0)
    JarvisState.SURPRISED -> Color(0xFFEAF4FF)
    JarvisState.CONCERNED -> Color(0xFFFFB86B)
    JarvisState.STRICT -> Color(0xFFFF7D6E)
}

class JarvisAudioReactor(private val controller: JarvisController) {
    private var audioRecord: AudioRecord? = null
    private var job: Job? = null
    private val sampleRate = 44100
    private val bufSize = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)

    @SuppressLint("MissingPermission")
    fun start(scope: CoroutineScope) {
        if (audioRecord != null) return
        audioRecord = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize)
        audioRecord?.startRecording()
        controller.setState(JarvisState.LISTENING)
        job = scope.launch(Dispatchers.Default) {
            val buffer = ShortArray(bufSize)
            while (isActive) {
                val read = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                if (read > 0) {
                    var sum = 0.0
                    for (i in 0 until read) sum += (buffer[i] * buffer[i]).toDouble()
                    controller.setLevel((sqrt(sum / read) / Short.MAX_VALUE * 6f).toFloat())
                }
            }
        }
    }

    fun stop() {
        job?.cancel(); audioRecord?.stop(); audioRecord?.release(); audioRecord = null
        controller.setLevel(0f)
    }
}
