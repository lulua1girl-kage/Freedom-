# Native Nori/Jarvis reference

The web artifact now includes a fifth selectable visual interface, **Nori Avatar**, based on the supplied Jetpack Compose avatar implementation.

Default remains **KAGE Classic**. The native implementation can bind the same `JarvisController.state` and `JarvisController.level` values to this avatar and the Aurora/HUD/Iris visual cores.

Recommended native setting: persist the selected skin and map `CLASSIC`, `AURORA`, `HUD`, `IRIS`, and `AVATAR` to the corresponding composable renderer.
