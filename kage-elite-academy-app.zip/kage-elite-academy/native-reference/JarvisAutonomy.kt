package com.yourapp.jarvis

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

class JarvisAutonomy(private val controller: JarvisController) {
    private var job: Job? = null
    private var baseline = 0f
    private var spikeCooldownUntil = 0L
    private var lastIdleFlicker = 0L

    fun start(scope: CoroutineScope) {
        if (job != null) return
        job = scope.launch {
            while (isActive) { tick(); delay(80) }
        }
    }

    fun stop() { job?.cancel(); job = null }

    private suspend fun tick() {
        val level = controller.level
        baseline += (level - baseline) * 0.05f
        val delta = level - baseline
        val now = System.currentTimeMillis()
        when {
            delta > 0.35f && now > spikeCooldownUntil -> {
                controller.setState(JarvisState.SURPRISED); spikeCooldownUntil = now + 1200
            }
            level > 0.12f && controller.state != JarvisState.SPEAKING -> controller.setState(JarvisState.LISTENING)
            (controller.state == JarvisState.LISTENING || controller.state == JarvisState.SURPRISED) && now > spikeCooldownUntil -> controller.setState(JarvisState.IDLE)
            controller.state == JarvisState.IDLE && now - lastIdleFlicker > Random.nextLong(14000, 26000) -> {
                lastIdleFlicker = now
                val flicker = listOf(JarvisState.ENCOURAGING, JarvisState.PROUD).random()
                controller.setState(flicker); delay(1400)
                if (controller.state == flicker) controller.setState(JarvisState.IDLE)
            }
        }
    }

    fun reactToReply(text: String) {
        val lower = text.lowercase()
        val reaction = when {
            listOf("error", "failed", "sorry", "wrong", "couldn't").any { it in lower } -> JarvisState.DISAPPOINTED
            listOf("done", "success", "completed", "finished").any { it in lower } -> JarvisState.SUCCESS
            listOf("great job", "well done", "nice work", "good job", "proud").any { it in lower } -> JarvisState.PROUD
            listOf("wow", "whoa", "unexpected", "surprising", "no way").any { it in lower } -> JarvisState.SURPRISED
            listOf("let's", "you can do", "keep going", "don't worry", "you got this").any { it in lower } -> JarvisState.ENCOURAGING
            else -> null
        }
        if (reaction != null) controller.setState(reaction)
    }
}
