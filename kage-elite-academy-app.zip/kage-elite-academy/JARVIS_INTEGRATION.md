# KAGE Nori / Jarvis Interface Integration

The Jarvis interactive face is an optional visual layer for Nori. **KAGE Classic is the default** so the existing Nori artwork remains the first-run experience.

## User-selectable interfaces

- **KAGE Classic** — existing Nori artwork and KAGE visual language (default)
- **Aurora** — concentric reactive rings and orbiting motion
- **Mark VII / HUD** — segmented rings, rotating core and precision ticks
- **Iris** — aperture-blade and spoke animation

The selected interface is persisted in local storage as `noriInterface` and does not change academic data, chat history, voice settings or memory.

## State model

The UI supports the same state vocabulary as the supplied Kotlin controller:

`IDLE`, `LISTENING`, `THINKING`, `SPEAKING`, `PROUD`, `DISAPPOINTED`, `ENCOURAGING`, `SUCCESS`, `SURPRISED`.

Voice chat changes the visual state as the session moves through listening, thinking and speaking. The native Android implementation can use the supplied `JarvisController` as the single source of truth and feed microphone/TTS amplitude into the visual core.

## Native bridge target

The web prototype is intentionally only the UI/interaction layer. On Android, wire the same state and level values to:

- `JarvisController.setState(...)`
- `JarvisController.setLevel(...)`
- `JarvisAudioReactor`
- Nori TTS amplitude
- Smart Alarm wake/session state
- KAGE handbook/consequence state

This keeps the visual choice independent from the underlying Nori intelligence and academic engines.
